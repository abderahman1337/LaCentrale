<!DOCTYPE html>
<html dir="ltr" lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Laravel')); ?> - <?php echo $__env->yieldContent('title'); ?></title>
        <link rel="icon" href="https://lacentrale.fr/static/fragment-head/media/favicon-32.cc0580c7.png" sizes="32x32">
        <link rel="apple-touch-icon" href="https://lacentrale.fr/static/fragment-head/media/favicon-180.61cbde72.png" sizes="180x180" />
        <link rel="icon" href="https://lacentrale.fr/static/fragment-head/media/favicon-192.86e99c0c.png" sizes="192x192" />
        <link rel="icon" href="https://lacentrale.fr/static/fragment-head/media/favicon-512.9de245d0.png" sizes="512x512" />
        <link rel="icon" href="https://lacentrale.fr/static/fragment-head/media/favicon.e47e4cf5.svg" type="image/svg+xml">
        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />
        <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300..800;1,300..800&display=swap" rel="stylesheet">

        <!-- Scripts -->
        <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
        <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    </head>
    <body class="font-sans antialiased">
        <?php if (isset($component)) { $__componentOriginal598e6db35128a97862f60d51138b6622 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal598e6db35128a97862f60d51138b6622 = $attributes; } ?>
<?php $component = App\View\Components\Home\Header::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('home.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Home\Header::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal598e6db35128a97862f60d51138b6622)): ?>
<?php $attributes = $__attributesOriginal598e6db35128a97862f60d51138b6622; ?>
<?php unset($__attributesOriginal598e6db35128a97862f60d51138b6622); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal598e6db35128a97862f60d51138b6622)): ?>
<?php $component = $__componentOriginal598e6db35128a97862f60d51138b6622; ?>
<?php unset($__componentOriginal598e6db35128a97862f60d51138b6622); ?>
<?php endif; ?>
        <div class="container lg:px-0 px-2 mx-auto">
            <?php echo $__env->yieldContent('content'); ?>
            <?php if (isset($component)) { $__componentOriginal18359df858d070db47133616a3b4b2ef = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal18359df858d070db47133616a3b4b2ef = $attributes; } ?>
<?php $component = App\View\Components\Home\Footer::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('home.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Home\Footer::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal18359df858d070db47133616a3b4b2ef)): ?>
<?php $attributes = $__attributesOriginal18359df858d070db47133616a3b4b2ef; ?>
<?php unset($__attributesOriginal18359df858d070db47133616a3b4b2ef); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal18359df858d070db47133616a3b4b2ef)): ?>
<?php $component = $__componentOriginal18359df858d070db47133616a3b4b2ef; ?>
<?php unset($__componentOriginal18359df858d070db47133616a3b4b2ef); ?>
<?php endif; ?>
        </div>
        <script src="<?php echo e(asset('js/scripts.js')); ?>"></script>
        <?php echo $__env->yieldContent('scripts'); ?>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\lacentrale\resources\views/layouts/home.blade.php ENDPATH**/ ?>